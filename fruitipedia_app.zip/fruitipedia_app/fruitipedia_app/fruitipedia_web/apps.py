from django.apps import AppConfig


class FruitipediaWebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fruitipedia_app.fruitipedia_web'
